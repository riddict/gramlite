<div class="xs">
<h3>Inbox</h3>
	<div class="col-md-12 inbox_right">
            <div class="mailbox-content">
               <div class="mail-toolbar clearfix">
               </div>
                <table class="table">
                    <tbody>
						<?php $__currentLoopData = $inboxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inbox): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr class="unread checked" onClick="show('thread', '<?php echo e($inbox->thread_id); ?>')">
                            <td>
							<?php if($inbox->has_newer == true): ?>
							<b><?php echo e($inbox->thread_title); ?></b>
							<?php else: ?>
								<?php echo e($inbox->thread_title); ?>

							<?php endif; ?>
                            </td>
                            <td class="hidden-xs">
								<?php if(isset($inbox->items[0]->text)): ?>
								<?php echo e($inbox->items[0]->text); ?>

								<?php else: ?>
								No Text
								<?php endif; ?>
                            </td>
                            <td>
							<?php echo e(date('d-m-Y', $inbox->viewer_id)); ?>

                            </td>
                        </tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
               </div>
    </div>
    <div class="clearfix"> </div>
</div>