<div class="xs">
<h3>Recent Activities</h3>
	<div class="col-md-12 email-list1">
               <ul class="collection">
			   <span class="email-title">Berita Terbaru</span><br />
			   <?php $__currentLoopData = $newnotis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newnoti): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="collection-item avatar email-unread">
                      <div class="avatar_left">
                        <p class="truncate grey-text ultra-small"><?php echo e($newnoti->args->text); ?></p>
                      </div>
                      <a href="#!" class="secondary-content"><span class="blue-text ultra-small"><?php echo e(date('m/d/Y', $newnoti->args->timestamp)); ?></span></a>
                      <div class="clearfix"> </div>
                    </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </ul>
    </div>
	<div class="clearfix"> </div>
	<div class="col-md-12 email-list1">
               <ul class="collection">
			   <span class="email-title">Berita Lebih Lama</span><br />
			   <?php $__currentLoopData = $notis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="collection-item avatar email-unread">
                      <div class="avatar_left">
                        <p class="truncate grey-text ultra-small"><?php echo e($noti->args->text); ?></p>
                      </div>
                      <a href="#!" class="secondary-content"><span class="blue-text ultra-small"><?php echo e(date('m/d/Y', $noti->args->timestamp)); ?></span></a>
                      <div class="clearfix"> </div>
                    </li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              </ul>
    </div>
    <div class="clearfix"> </div>
</div>