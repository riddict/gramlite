<div class="xs">
<h3>Inbox</h3>
	<div class="col-md-12 inbox_right">
            <div class="mailbox-content">
               <div class="mail-toolbar clearfix">
               </div>
                <table class="table">
                    <tbody>
					<?php $__currentLoopData = $threads['thread']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr class="unread checked">
                            <td>
                                <?php echo $i->getUsernameInfo($thread['user_id'])->getUser()->getUsername(); ?>
                            </td>
                            <td>
							<?php if($thread['item_type'] == "text"): ?>
								<?php echo e($thread['text']); ?>

							<?php elseif($thread['item_type'] == "media_share"): ?>
								<?php echo e($thread['media_share']['caption']['text']); ?> <br /> 
							<?php elseif($thread['item_type'] == "like"): ?>
								<span class="fa fa-heart"></span><br /> 
							<?php else: ?>
								<?php echo e($thread['item_type']); ?><br />
							<?php endif; ?>
                            </td>
                        </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </tbody>
                </table>
				
					<?php if($threads['thread']['pending'] == true): ?>
						<a href="" onClick="show('terima', '<?php echo e($threads['thread']['thread_id']); ?>')">Terima</a>  |  <a href="" onClick="show('tolak')">Tolak</a><br />
					<?php else: ?>
						<br />
					<?php endif; ?>
            </div>
			   
    </div>
	<br />
	<div class="clearfix"> </div>
	<div class="col-md-12 inbox_right">
        	<div class="Compose-Message">               
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Reply 
                    </div>
                    <div class="panel-body">
                        <!--<div class="alert alert-info">
                            Please fill details to send a new message
                        </div>-->
						<form  class="ajax" id="ajax" action="<?php echo e(URL('sendmsg')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

                        <label>Enter Message : </label>
						<input type="hidden" name="userid" value="<?php echo e($threads['thread']['users'][0]['pk']); ?>">
						<input type="hidden" name="threadid" value="<?php echo e($threads['thread']['thread_id']); ?>">
                        <textarea rows="6" class="form-control1 control2" name="text"></textarea>
                        <hr>
						<input type="submit" class="btn-success btn" name="reply" id="sendmsg" value="Balas Pesan">
						</form>
                    </div>
                 </div>
              </div>
         </div>
    <div class="clearfix"> </div>
</div>