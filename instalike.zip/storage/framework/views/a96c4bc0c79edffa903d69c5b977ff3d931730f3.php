<?php $__env->startSection('script'); ?>
$(document).on('submit', 'form.comments', function (event) {
    event.preventDefault();
	var mediaid = $('#mediaid').val();
	$('#commentload_'+mediaid).after('<center><i class="fa fa-gear fa-spin" style="font-size:24px"></i> posting comment</center>');
    $.ajax({
        type: "get",
        url: $(this).attr('action'),
        data: $('#comments').serialize(),
		success: function( data ) {
			$('#commentload_'+mediaid).append(data);
		},
		error: function(data) {
			$('#pesan').append('<div class="alert alert-warning"><h4><i class="icon fa fa-warning"></i> Perhatian!</h4>Terjadi kesalahan. Coba lagi!</div>');
		}
    })
});

function addbookmark(username, type)
{
	$.ajax({
		headers : {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
		type: 'POST',
		url: '<?php echo e(URL('bookmark')); ?>',
		data:'username='+username+'&type='+type,
		success:function(msg){
			if(type == 0){
				$('#bookmark').removeClass("btn btn-sm btn-primary").addClass("btn btn-sm btn-default").attr("onclick", "addbookmark('"+username+"',1)").html('Add Bookmark');
			}else{
				$('#bookmark').removeClass("btn btn-sm btn-default").addClass("btn btn-sm btn-primary").attr("onclick", "addbookmark('"+username+"',0)").html('Delete Bookmark');
			}			
        }
	});
}

function follow(userid, type)
{
	$.ajax({
		headers : {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
		type: 'GET',
		url: '<?php echo e(URL('follow')); ?>',
		data:'userid='+userid+'&type='+type,
		success:function(msg){
			if(type == 0){
				$('#follow').removeClass("btn btn-sm btn-primary").addClass("btn btn-sm btn-default").attr("onclick", "follow('"+userid+"',1)").html('Follow');
			}else{
				$('#follow').removeClass("btn btn-sm btn-default").addClass("btn btn-sm btn-primary").attr("onclick", "follow('"+userid+"',0)").html('Unfollow');
			}			
        }
	});
}

function cwRating(id,type,target){
	if(type == 0){
		$('#like'+id).removeClass("fa fa-heart text-info icon_13").addClass("fa fa-thumbs-down").attr("onclick", "cwRating('"+id+"',1,'like_count"+id+"')");
		}else{
		$('#like'+id).removeClass("fa fa-heart-o text-info icon_13").addClass("fa fa-thumbs-up").attr("onclick", "cwRating('"+id+"',0,'like_count"+id+"')");
	}	
    $.ajax({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
        type:'POST',
        url:'<?php echo e(URL('likemedia')); ?>',
        data:'id='+id+'&type='+type,
        success:function(msg){
			if(type == 0){
				$('#'+target).html(msg);
				$('#like'+id).removeClass("fa fa-thumbs-down").addClass("fa fa-heart-o text-info icon_13").attr("onclick", "cwRating('"+id+"',1,'like_count"+id+"')");
			}else{
				$('#'+target).html(msg);
				$('#like'+id).removeClass("fa fa-thumbs-up").addClass("fa fa-heart text-info icon_13").attr("onclick", "cwRating('"+id+"',0,'like_count"+id+"')");
			}			
        },
		error: function(msg) {
			$('#pesan').append('<div class="alert alert-warning"><h4><i class="icon fa fa-warning"></i> Perhatian!</h4>Gagal ngelike</div>');
			$('#like'+id).removeClass("fa fa-thumbs-up").addClass("fa fa-heart-o").attr("onclick", "cwRating('"+id+"',0,'like_count"+id+"')");
		}
    });
}

function nextfeed(maxid){
	var url = "<?php echo e(URL($user.'/feed/')); ?>";
	$.ajax({
        type:'GET',
        url: url+'/'+maxid,
        success: function( data ) {
			$('#feeds').append(data);
		},
		error: function(data) {
			$('#pesan').append('<div class="alert alert-warning"><h4><i class="icon fa fa-warning"></i> Perhatian!</h4>Tidak ada media lagi</div>');
		}
    });
}

function loadcm(id){
	event.preventDefault();
	$('#commentload_'+id).html('<center><i class="fa fa-gear fa-spin" style="font-size:24px"></i></center>');
	var url = "<?php echo e(URL('viewcomment')); ?>/"+id;
	$.ajax({
		type:'GET',
		url: url,
		success: function( data ) {
			$('#commentload_'+id).html(data);
		},
		error: function(data) {
		$('#pesan').after('<div class="alert alert-warning"><h4><i class="icon fa fa-warning"></i> Perhatian!</h4>Gagal memuat komentar</div>');
		}
	});
}

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="clear"> </div>
<div class="col_1">
	<div id="pesan"></div>
	<div class="col-md-12 span_8">
		<div class="activity_box">
			<div class="wid_blog">
		   		<h4><?php echo e($user); ?></h4>
				<?php if(is_null($ada)): ?>
					<button id="bookmark" type="button" class="btn btn-sm btn-default" onClick="addbookmark('<?php echo e($user); ?>', 1)">Add Bookmark</button>
				<?php else: ?>
					<button id="bookmark" type="button" class="btn btn-sm btn-primary" onClick="addbookmark('<?php echo e($user); ?>', 0)">Delete Bookmark</button>
				<?php endif; ?>
				<?php if($friend == false): ?>
					<button id="follow" type="button" class="btn btn-sm btn-default" onClick="follow('<?php echo e($userid); ?>', 1)">Follow</button>
				<?php else: ?>
					<button id="follow" type="button" class="btn btn-sm btn-primary" onClick="follow('<?php echo e($userid); ?>', 0)">Unfollow</button>
				<?php endif; ?>
		   	</div>
			
		    <div class="scrollbar" id="style-2">
                <div id="feeds" class="activity-row">
				<?php if($friend == true | $private == false): ?>
					<?php $__currentLoopData = $feeds->getItems(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<div id="<?php echo e($feed->getId()); ?>div">
							<?php if(is_null($feed->getCaption())): ?>
								No caption<br />
							<?php else: ?>
								<p>
									<?php $text = $feed->getCaption()->getText();
										$text = preg_replace('/(^|)@([a-z0-9_.]+)/i',
										'$1<a href="'.URL('$2/feed').'">@$2</a>', $text);
										$newtext = preg_replace('/\r?\n|\r/','<br/>', $text);
										echo $newtext.'<br />';
									?>
								</p>
							<?php endif; ?>
							<?php if($feed->getHasLiked() == 1): ?>
								<span id="like<?php echo e($feed->getId()); ?>" class="fa fa-heart" onClick="cwRating('<?php echo e($feed->getId()); ?>',0,'like_count<?php echo e($feed->getId()); ?>')"></span>
							<?php else: ?>
								<span id="like<?php echo e($feed->getId()); ?>" class="fa fa-heart-o" onClick="cwRating('<?php echo e($feed->getId()); ?>',1,'like_count<?php echo e($feed->getId()); ?>')"></span>
							<?php endif; ?>
							<span class="counter" id="like_count<?php echo e($feed->getId()); ?>"><?php echo e($feed->getLikeCount()); ?></span> likes  |  
							<?php if($feed->getCommentCount() > 0): ?>
								<span class="fa fa-comment" onClick="loadcm('<?php echo e($feed->getId()); ?>')"></span> <?php echo e($feed->getCommentCount()); ?> comments
							<?php else: ?>
								<span class="fa fa-comment-o" onClick="loadcm('<?php echo e($feed->getId()); ?>')"></span> <?php echo e($feed->getCommentCount()); ?> comment
							<?php endif; ?>
							<div id="commentload_<?php echo e($feed->getId()); ?>"></div>
						</div>
						<div class="clearfix"> </div>
						<br />
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					<br /><a id="max" href="#" onClick="nextfeed('<?php echo e($feeds->getNextMaxId()); ?>')">Load More</a>
				<?php else: ?>
					Account Instagram ini dalam keadaan tergembok. Follow dulu kalau mau ngintip.
				<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="clearfix"> </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modern.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>