<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="col_3">
			<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <div class="stats">
						<div class="col-xs-3 activity-img"><img src='<?php echo e($usernameinfo->getUser()->getProfilePicUrl()); ?>' class="img-responsive" alt=""/></div>
						<h5><strong><?php echo e($usernameinfo->getUser()->getUsername()); ?></strong></h5>
						<span><?php echo e($usernameinfo->getUser()->getBiography()); ?></span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($usernameinfo->getUser()->getFollowerCount()); ?></strong></h5>
                      <span>Followers</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-users user1 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($usernameinfo->getUser()->getFollowingCount()); ?></strong></h5>
                      <span>Following</span>
                    </div>
                </div>
        	</div>
        	<div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left fa fa-comment user2 icon-rounded"></i>
                    <div class="stats">
                      <h5><strong><?php echo e($usernameinfo->getUser()->getMediaCount()); ?></strong></h5>
                      <span>Media</span>
                    </div>
                </div>
        	</div>
        	<div class="clearfix"> </div>
    </div>
	<div class="col_1">
		<div class="col-md-4 stats-info">
            <div class="panel-heading">
                <h4 class="panel-title">Bookmark</h4>
            </div>
            <div class="panel-body">
                <ul class="list-unstyled">
				<?php $__currentLoopData = $bookmark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><a href=" <?php echo e(URL($mark->username.'/feed')); ?>"><?php echo e($mark->username); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="clearfix"> </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('modern.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>