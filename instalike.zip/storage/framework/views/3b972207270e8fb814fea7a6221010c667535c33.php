<div class="but_list">
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<div class="well">
<b><?php echo e($comment->getUser()->getUsername()); ?></b>
	<?php $text = $comment->getText();
	$text = preg_replace('/(^|\s)@([a-z0-9_.]+)/i',
										'$1<a href="'.URL('$2/feed').'">@$2</a>', $text);
										$newtext = preg_replace('/\r?\n|\r/','<br/>', $text);
										echo $newtext.'<br />';
	?>


</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<form action="<?php echo e(URL('commenting')); ?>" method="get" class="comments" id="comments">

<input type="hidden" name="mediaid" value=" <?php echo e($mediaid); ?>">
<div class="input-group">
<input disabled="" type="text" name="text" class="form-control1" placeholder="belum berfugsi komennya">
<div class="input-group-addon"><input type="submit" value="Go"></div>
</div>
</form>