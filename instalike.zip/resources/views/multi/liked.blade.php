@extends('multi.layouts.app')
@section('script')
@endsection
@section('content')
<div class="profile-agile">
	<div class="w3layouts">
		@foreach($medias['items'] as $media)
			<img src=" {{ $media['image_versions2']['candidates'][0]['url'] }}" ><br />
		@endforeach	
	</div>
</div>
@endsection