@extends('multi.layouts.app')
@section('script')
@endsection
@section('content')
<div class="weather-agile">
	<div class="search-w3">
	@if($type == "user")
		<form action="{{ URL('search') }}" method="post">
			{{ csrf_field() }}
			<input type="submit" value=" ">
			<input type="text" name="uname" placeholder="Search" required="">
	@else
			<input type="submit" value=" ">
			<form action="{{ URL('searchht') }}" method="get">
	@endif
		</form>
	</div>
	@if($type == "user")
	<div class="scrollbar" id="style-2">
			@foreach($users as $user)
			<ul><li><a href=" {{ URL($user->getUsername().'/feed') }}" > {{ $user->getUsername() }}</a></li></ul>
			@endforeach
	</div>
	@else
	<div class="scrollbar" id="style-2">
			@foreach($results as $result)
			<ul><li>#{{ $result['name'] }} | {{ $result['media_count'] }} media<br /></li></ul>
			@endforeach
	</div>
	@endif
</div>
@endsection