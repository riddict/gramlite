@extends('multi.layouts.app')
@section('script')
@endsection
@section('content')
<div class="profile-agile">
	<div class="search-w3">
		<form action="{{ URL('search') }}" method="post">
			{{ csrf_field() }}
			<input type="submit" value=" ">
			<input type="text" name="uname" placeholder="Search" required="">
		</form>
	</div>
	<div class="w3layouts">
		<img src="{{ $profil->getProfilePicUrl() }}" alt=" " />
		<h3>{{ $profil->getFullName() }}</h3>
		<label class="line"></label>
		<p>{{ $profil->getBiography() }}</p>
	</div>
	<div class="agileits-w3layouts">
		<div class="w3l">
			<h4>{{ $usernameinfo->getFollowerCount() }}</h4>
			<h5>Follower</h5>
		</div>
		<div class="w3-agile">
			<h4>{{ $usernameinfo->getFollowingCount() }}</h4>
			<h5>Follower</h5>
		</div>
		<div class="clear"></div>
	</div>
</div>
@endsection
