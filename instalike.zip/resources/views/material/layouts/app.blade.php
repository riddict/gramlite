<!DOCTYPE html>
<html>
<head>
	<title>Gram Client</title>
	<!--Custom Theme files-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Custom Theme files -->
	<link href="{{ URL('material/css/style.css') }}" rel="stylesheet" type="text/css" media="all" />
	<!--web-fonts-->
	<link href='//fonts.googleapis.com/css?family=Jura:400,300,500,600' rel='stylesheet' type='text/css'>
	<link type="text/css" rel="stylesheet" href="{{ URL('material/css/jquery.mmenu.all.css?v=5.4.4') }}" />
	<!--//web-fonts-->
	<!-- js -->
	<script src="{{ URL('material/js/jquery-1.11.1.min.js') }}"></script> 
	<script type="text/javascript" src="{{ URL('material/js/jquery.mmenu.min.all.js?v=5.4.4') }}"></script>
	<!-- //js -->
	@yield('script')
</head>
<body>
	<h1>Gram Client</h1>
<div class="main">
	<div class="login-form">
		<div class="banner">
			<div class="banner-text">
				<div class="menu">
					<span class="menu-icon"><a href="#"><img src="{{ URL('material/images/menu-icon.png') }}" alt=""/></a></span>	
						<ul class="nav1">
							<li><a href="{{ URL('home') }}">Home</a></li>
							<li><a href="{{ URL('liked') }}">Post You Liked</a></li>
							<li><a href="{{ URL('search/tags/') }}">Search Hashtags</a></li>
							<li><a href="{{ URL($profil->getUsername().'/feed') }}">Your Timeline</a></li>
							<li><a href="{{ URL('setting') }}">Settings</a></li>
						</ul> 	
						<!-- script-for-menu -->
						<script>
						   $( "span.menu-icon" ).click(function() {
							 $( "ul.nav1" ).slideToggle( 300, function() {
							 // Animation complete.
							  });
							 });
						</script>
						<!-- /script-for-menu -->
				</div>
				<div class="title">
					<div class="title-left">
						<!--<img src="{{ $profil->getProfilePicUrl() }}" alt=""/>-->
					</div>
					<div class="title-right">
						<h2>{{ $profil->getFullName() }}</h2>
						<h6>{{ $profil->getBiography() }}</h6>
					</div>
					<div class="clear"> </div>
				</div>
			</div>
		</div>
		@yield('content')
	</div>
</div>
<div class="copyright">
<!-- Authentication Links -->
    @if (Auth::guest())
    
    @else
	<p class="agileinfo">
	<a href="{{ url('/logout') }}"
		onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">Logout</a>
	<form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
        {{ csrf_field() }}
    </form>
	</p>
	@endif
<p> &copy; 2016 Mobile material . All rights reserved | Template by <a href="http://w3layouts.com/" target="_blank" >W3layouts</a></p>
</div>
</body>
</html>
