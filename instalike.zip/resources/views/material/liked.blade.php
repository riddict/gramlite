@extends('material.layouts.app')
@section('script')
@endsection
@section('content')
<div class="clear"> </div>
<div class="work-text">
	<section class="ac-container">
		
		@foreach($medias['items'] as $media)
			<img src=" {{ $media['image_versions2']['candidates'][0]['url'] }}" ><br />
		@endforeach	
	</section>
</div>
@endsection