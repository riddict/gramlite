@extends('material.layouts.app')
@section('script')
<script type="text/javascript">
/**
* Function Name: cwRating()
* Function Author: CodexWorld
* Description: cwRating() function is used for implement the rating system. cwRating() function insert like or dislike data into the database and display the rating count at the target div.
* id = Unique ID, like or dislike is based on this ID.
* type = Use 1 for like and 0 for dislike.
* target = Target div ID where the total number of likes or dislikes will display.
**/
function cwRating(id,type,target){
    $.ajax({
		headers: {
			'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		},
        type:'POST',
        url:'{{ URL('likemedia') }}',
        data:'id='+id+'&type='+type,
        success:function(msg){
                $('#'+target).html(msg);
$('#like'+id).html('unlike');
$('#unlike'+id).html('like');
        }
    });
}
</script>
@endsection
@section('content')
<div class="clear"> </div>
<div class="work-text">
	<section class="ac-container">
		<h3>{{ $user }} Timeline</h3>
		<a href="{{ URL($user.'/feed/'.$feeds->getNextMaxId()) }}">Next Feeds</a>
			@foreach ($feeds->getItems() as $feed)
				<div id="{{ $feed->getMediaId() }}div">
					@if(is_null($feed->getCaption()))
						No caption
					@else
						<p>
							<?php $text = $feed->getCaption()->getText();
							$text = preg_replace('/(^|\s)@([a-z0-9_.]+)/i',
								 '$1<a href="'.URL('$2/feed').'">@$2</a>', $text);
							echo $text.'<br />';
							?>
						</p>
					@endif
						<span class="counter" id="like_count{{ $feed->getMediaId() }}">{{ $feed->getLikeCount() }}</span>
					@if($feed->hasLiked() == true)
						<a id="unlike{{ $feed->getMediaId() }}" href="#{{ $feed->getMediaId() }}div" onClick="cwRating('{{ $feed->getMediaId() }}',0,'like_count{{ $feed->getMediaId() }}')">Unlike</a>
					@else
						<a id="like{{ $feed->getMediaId() }}" href="#{{ $feed->getMediaId() }}div" onClick="cwRating('{{ $feed->getMediaId() }}',1,'like_count{{ $feed->getMediaId() }}')">Like</a>
					@endif
				</div>
				<div class="clear"> </div>
				<br /><br />
			@endforeach
	</section>
</div>
@endsection