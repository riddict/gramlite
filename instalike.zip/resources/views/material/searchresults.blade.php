@extends('material.layouts.app')
@section('script')
@endsection
@section('content')
<div class="clear"> </div>
<div class="work-text">
	<section class="ac-container">
		<div class="signin-form">
			@if($type == "user")
			<form action="{{ URL('search') }}" method="get">
				<input type="submit" value=" ">
				<input type="text" name="uname" placeholder="Search" required="">
			@else
			<form action="{{ URL('searchht') }}" method="get">
				<input type="submit" value=" ">
				<input type="text" name="hashtags" placeholder="Search" required="">
			@endif
			</form>		
		</div>
		@if($type == "user")
			@foreach($users as $user)
			<div>
				<ul><li><a href=" {{ URL($user->getUsername().'/feed') }}" > {{ $user->getUsername() }}</a></li></ul>
			</div>
			@endforeach
		@else
			@foreach($results as $result)
			<div>
				<ul><li>#{{ $result['name'] }} | {{ $result['media_count'] }} media<br /></li></ul>
			</div>
			@endforeach
		@endif
	</section>
</div>
@endsection