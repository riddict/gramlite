@extends('material.layouts.app')
@section('script')
@endsection
@section('content')
<div class="clear"> </div>
<div class="signin-form">
	<p>Search Hashtags</p><br />
	<form action="{{ URL('searchht') }}" method="get">
		<input type="text" name="hashtags" placeholder="Search" required="">
		<input type="submit" value="Search">
	</form>
</div>
@endsection
