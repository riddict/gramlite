@extends('material.layouts.app')
@section('script')
@endsection
@section('content')
	{{ $pesan }}
	<div class="clear"> </div>
	<div class="work-text">
		<section class="ac-container">
			
			Pilih tampilan Gram CLient<br /><br />
			<form action="{{ URL('setting') }}" method="post">
				{{ csrf_field() }}
				<select name="themes">
					<option value="{{ Auth::user()->themes }}" selected>{{ Auth::user()->themes }} themes</option>
					<option value="default">Default Themes</option>
					<option value="material">Material Themes</option>
				</select>
				<br><br>
				<div>
				<input id="ac-1" type="checkbox" name="accordion-1" value="images_on"><label for="ac-1" class="grid1">Images on/off</label>
				<article class="ac-small">
					<p>Tampilkan atau sembunyikan gambar di Gram Client</p>
				</article>
				</div>
				<input type="submit" value="Simpan">
			</form>
			@if(is_null($akun))
				Tambahkan Instagram Account<br />
			@else
				Hapus Akun Instagram dari Gram Client Klik <a href="{{ URL('delakun') }}">di sini<a/><br />
			@endif
			
		</section>
	</div>
@endsection