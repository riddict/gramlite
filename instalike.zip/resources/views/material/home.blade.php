@extends('material.layouts.app')
@section('script')
@endsection
@section('content')
<div class="clear"> </div>
<div class="banner-bottom">
		<div class="banner-bottom-left">
			<h3>{{ $usernameinfo->getFollowerCount() }}</h3>
			<p>Followers </p>
		</div>
		<div class="banner-bottom-right">
			<h3>{{ $usernameinfo->getFollowingCount() }}</h3>
			<p>Following</p>
		</div>
	<div class="clear"> </div>
</div>
<div class="signin-form">
	<p>Search Username</p><br />
	<form action="{{ URL('search') }}" method="post">
		{{ csrf_field() }}
		<input type="text" name="uname" placeholder="Search" required="">
		<input type="submit" value="Search">
	</form>
</div>

@endsection
